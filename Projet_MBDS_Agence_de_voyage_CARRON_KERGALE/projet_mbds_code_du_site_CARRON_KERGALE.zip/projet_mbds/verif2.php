
<?php 

	$dbHost = "144.21.67.201";
	$dbHostPort ="1521";
	$dbServiceName ="pdbest21.631174089.oraclecloud.internal";
	$usr= 'CARON2B20';
	$pswd= 'CARON2B2001';
	$dbConnStr = "(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)
	(HOST =".$dbHost.")(PORT = ".$dbHostPort."))
	(CONNECT_DATA = (SERVICE_NAME = ".$dbServiceName.")))";

	if($dbConn=oci_connect($usr,$pswd, $dbConnStr)){
		$err=oci_error();
		trigger_error("Connexion non établie : " .$err ['message'], E_USER_ERROR);
	}
	else
	{
		echo "Connecté(e)";
	}

	if($username !== "" && $password !== "")
    {
        $requete = 'SELECT count(*) FROM employes where 
              EMAILEMPLOYE = '.$username.' and MDP = '.$password.' ';
        $exec_requete = oci_parse($dbConnStr,$requete);
        $reponse = oci_result($exec_requete);
        $count = $reponse['count(*)'];
        if($count!=0) // nom d'utilisateur et mot de passe correctes
        {
           $_SESSION['username'] = $username;
           header('Location: connexion.php');
        }
        else
        {
           header('Location: login.php?erreur=1'); // utilisateur ou mot de passe incorrect
        }
    }
    else
    {
       header('Location: login.php?erreur=2'); // utilisateur ou mot de passe vide
    }
}
else
{
   header('Location: login.php');
}
?>
